from matplotlib import _api


_api.warn_deprecated("3.3", name=__name__, obj_type="module")
