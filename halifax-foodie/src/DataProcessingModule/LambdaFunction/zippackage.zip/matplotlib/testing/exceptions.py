class ImageComparisonFailure(AssertionError):
    """
    Raise this exception to mark a test as a comparison between two images.
    """
